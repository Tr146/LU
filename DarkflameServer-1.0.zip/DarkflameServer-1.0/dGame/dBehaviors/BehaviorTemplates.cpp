﻿#include "BehaviorTemplates.h"

﻿#pragma once

enum class MissionLockState : int
{
	MISSION_LOCK_LOCKED,
	MISSION_LOCK_NEW,
	MISSION_LOCK_UNLOCKED,
};

#pragma once
#include "CppScripts.h"

class AgPicnicBlanket : public CppScripts::Script {
    void OnUse(Entity *self, Entity *user) override;
};

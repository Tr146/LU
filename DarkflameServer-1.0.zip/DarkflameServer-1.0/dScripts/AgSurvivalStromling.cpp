#include "AgSurvivalStromling.h"

uint32_t AgSurvivalStromling::GetPoints() {
    return 100;
}

#pragma once
#include "CppScripts.h"

class AmNamedDarklingDragon : public CppScripts::Script
{
public:
    void OnStartup(Entity* self) override;
};

#pragma once
#include "CppScripts.h"

class AgCagedBricksServer : public CppScripts::Script {
	void OnUse(Entity* self, Entity* user);
};
#pragma once
#include "CppScripts.h"

class AgDarkSpiderling : public CppScripts::Script {
    void OnStartup(Entity *self) override;
};

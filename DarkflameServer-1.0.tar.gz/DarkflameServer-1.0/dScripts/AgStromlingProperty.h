#pragma once
#include "CppScripts.h"

class AgStromlingProperty : public CppScripts::Script {
    void OnStartup(Entity *self) override;
};

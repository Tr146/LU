#pragma once
#include "BaseWavesGenericEnemy.h"

class AgSurvivalStromling : public BaseWavesGenericEnemy {
    uint32_t GetPoints() override;
};

#pragma once
#include "BaseEnemyMech.h"

class AgDarklingMech : public BaseEnemyMech {
    void OnStartup(Entity* self) override;
};

﻿#include "EmptyBehavior.h"


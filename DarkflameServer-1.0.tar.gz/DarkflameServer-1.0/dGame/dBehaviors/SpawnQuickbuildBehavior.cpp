﻿#include "SpawnQuickbuildBehavior.h"

#include "BehaviorBranchContext.h"
#include "BehaviorContext.h"

void SpawnQuickbuildBehavior::Handle(BehaviorContext* context, RakNet::BitStream* bitStream, BehaviorBranchContext branch)
{
}

void SpawnQuickbuildBehavior::Load()
{
}
 
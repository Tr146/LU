﻿#pragma once

enum class BehaviorSlot
{
	Invalid = -1,
	Primary,
	Offhand,
	Neck,
	Head,
	Consumable
};

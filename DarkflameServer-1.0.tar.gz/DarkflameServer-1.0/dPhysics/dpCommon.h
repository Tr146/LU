#pragma once

enum class dpShapeType : unsigned short {
	Invalid = 0,
	Sphere,
	Box
};
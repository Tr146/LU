#pragma once
#include "RakNetTypes.h"
#include "RakPeer.h"

#define NET_PASSWORD_EXTERNAL "3.25 ND1"
#define NET_PASSWORD_INTERNAL "3.25 DARKFLAME1"